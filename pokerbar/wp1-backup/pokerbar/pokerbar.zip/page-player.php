<?php
get_header();
?>
<!-- CONTAIN_START -->
<main>
    <section class="pg_fv">
        <div class="pgfv_back">
            <img class="pgfv_bg" src="<?php echo get_stylesheet_directory_uri(); ?>/images/pg_player.jpg">
        </div>
        <div class="pgfv_front">
            <div class="pgfv_text">
                <h1 class="pani4 js-split">Player</h1>
                <div class="pgfv_uline"></div>
            </div>
        </div>
    </section>
    <div class="pgplayer_pad">
        <div class="cwidth12">
            <div class="player_grid">
                <div class="player_item io fade upS">
                    <div class="player_thumb">
                        <div class="player_img">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/player01.jpg">
                            <div class="plname_abs">
                                Shimizu Nozomu
                            </div>
                        </div>
                    </div>
                    <div class="plrank_gold">
                        <div class="plrank_cap">TOTAL LIVE EARNINGS</div>
                        <div class="plrank_val">$1,208,453</div>
                    </div>
                    <div class="plrank_gold">
                        <div class="plrank_cap">Japan All Time Money List</div>
                        <div class="plrank_val"> 12th</div>
                    </div>
                    <div class="plrank_silver">
                        <div class="plrank_cap">54th WSOP $5,000 NLH #9</div>
                        <div class="plrank_val">3rd</div>
                    </div>
                    <div class="plrank_silver">
                        <div class="plrank_cap">54th WSOP $5,000 NLH #9</div>
                        <div class="plrank_val">3rd</div>
                    </div>
                    <div class="plrank_silver">
                        <div class="plrank_cap">54th WSOP $5,000 NLH #9</div>
                        <div class="plrank_val">3rd</div>
                    </div>
                </div>
                <div class="player_item io fade upS">
                    <div class="player_thumb">
                        <div class="player_img">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/player01.jpg">
                            <div class="plname_abs">
                                Shimizu Nozomu
                            </div>
                        </div>
                    </div>
                    <div class="plrank_gold">
                        <div class="plrank_cap">TOTAL LIVE EARNINGS</div>
                        <div class="plrank_val">$1,208,453</div>
                    </div>
                    <div class="plrank_gold">
                        <div class="plrank_cap">Japan All Time Money List</div>
                        <div class="plrank_val"> 12th</div>
                    </div>
                    <div class="plrank_silver">
                        <div class="plrank_cap">54th WSOP $5,000 NLH #9</div>
                        <div class="plrank_val">3rd</div>
                    </div>
                    <div class="plrank_silver">
                        <div class="plrank_cap">54th WSOP $5,000 NLH #9</div>
                        <div class="plrank_val">3rd</div>
                    </div>
                    <div class="plrank_silver">
                        <div class="plrank_cap">54th WSOP $5,000 NLH #9</div>
                        <div class="plrank_val">3rd</div>
                    </div>
                </div>
                <div class="player_item io fade upS">
                    <div class="player_thumb">
                        <div class="player_img">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/player01.jpg">
                            <div class="plname_abs">
                                Shimizu Nozomu
                            </div>
                        </div>
                    </div>
                    <div class="plrank_gold">
                        <div class="plrank_cap">TOTAL LIVE EARNINGS</div>
                        <div class="plrank_val">$1,208,453</div>
                    </div>
                    <div class="plrank_gold">
                        <div class="plrank_cap">Japan All Time Money List</div>
                        <div class="plrank_val"> 12th</div>
                    </div>
                    <div class="plrank_silver">
                        <div class="plrank_cap">54th WSOP $5,000 NLH #9</div>
                        <div class="plrank_val">3rd</div>
                    </div>
                    <div class="plrank_silver">
                        <div class="plrank_cap">54th WSOP $5,000 NLH #9</div>
                        <div class="plrank_val">3rd</div>
                    </div>
                    <div class="plrank_silver">
                        <div class="plrank_cap">54th WSOP $5,000 NLH #9</div>
                        <div class="plrank_val">3rd</div>
                    </div>
                </div>
                <div class="player_item io fade upS">
                    <div class="player_thumb">
                        <div class="player_img">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/player01.jpg">
                            <div class="plname_abs">
                                Shimizu Nozomu
                            </div>
                        </div>
                    </div>
                    <div class="plrank_gold">
                        <div class="plrank_cap">TOTAL LIVE EARNINGS</div>
                        <div class="plrank_val">$1,208,453</div>
                    </div>
                    <div class="plrank_gold">
                        <div class="plrank_cap">Japan All Time Money List</div>
                        <div class="plrank_val"> 12th</div>
                    </div>
                    <div class="plrank_silver">
                        <div class="plrank_cap">54th WSOP $5,000 NLH #9</div>
                        <div class="plrank_val">3rd</div>
                    </div>
                    <div class="plrank_silver">
                        <div class="plrank_cap">54th WSOP $5,000 NLH #9</div>
                        <div class="plrank_val">3rd</div>
                    </div>
                    <div class="plrank_silver">
                        <div class="plrank_cap">54th WSOP $5,000 NLH #9</div>
                        <div class="plrank_val">3rd</div>
                    </div>
                </div>
                <div class="player_item io fade upS">
                    <div class="player_thumb">
                        <div class="player_img">
                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/player01.jpg">
                            <div class="plname_abs">
                                Shimizu Nozomu
                            </div>
                        </div>
                    </div>
                    <div class="plrank_gold">
                        <div class="plrank_cap">TOTAL LIVE EARNINGS</div>
                        <div class="plrank_val">$1,208,453</div>
                    </div>
                    <div class="plrank_gold">
                        <div class="plrank_cap">Japan All Time Money List</div>
                        <div class="plrank_val"> 12th</div>
                    </div>
                    <div class="plrank_silver">
                        <div class="plrank_cap">54th WSOP $5,000 NLH #9</div>
                        <div class="plrank_val">3rd</div>
                    </div>
                    <div class="plrank_silver">
                        <div class="plrank_cap">54th WSOP $5,000 NLH #9</div>
                        <div class="plrank_val">3rd</div>
                    </div>
                    <div class="plrank_silver">
                        <div class="plrank_cap">54th WSOP $5,000 NLH #9</div>
                        <div class="plrank_val">3rd</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<!-- CONTAIN_END -->
<?php
get_footer();
