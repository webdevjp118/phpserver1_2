<?php
get_header();
?>
<!-- CONTAIN_START -->
<?php get_template_part('template-parts/background-ad'); ?>
<section id="contain" class="content_section">
    <?php get_template_part('template-parts/ad-area'); ?>
    <?php get_template_part('template-parts/top-menu'); ?>
    <div class="poker_width">
        <div class="news_block_tp">
            <div class="poker_cwidth">
                <div class="hx4 block_pc"></div>
                <div class="news_title_tp">
                    <div class="common_title_hp">
                        <div class="X_deco"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/common_title_deco.svg"></div>
                        <h2>News</h2> 
                    </div>
                </div>
                <div class="titline_btn flex_pc">
                    <a class="com_job_btn" href="<?php echo get_site_url(); ?>/news/">
                        <span>MORE</span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="6.683" height="10.538" viewBox="0 0 6.683 10.538">
                            <path d="M62.651,13.834,67.212,18.4l-4.562,4.562" transform="translate(-61.944 -13.127)" fill="none" stroke-width="2"/>
                        </svg>                              
                    </a>  
                </div>
                <div class="hx2"></div>
                <div class="news_row_tp">
<?php
$tpnews_query = new WP_Query( 
    array(
        'post_type' => 'post',
        'posts_per_page' => 5,
    )
);
$tpnews_ids = [];
if ( $tpnews_query->have_posts() ) :
    while ( $tpnews_query->have_posts() ) :
        $tpnews_query->the_post();
        $loop_id = get_the_id();
        array_push($tpnews_ids, $loop_id);
    endwhile;
endif;
?>                    
<?php
if(count($tpnews_ids) > 0) {
    $loop_id = $tpnews_ids[0];
    $loop_title = get_the_title();
    $loop_content = get_the_excerpt();
    $loop_date = get_the_date('Y.m.d');
    $loop_category_name = "";
    $loop_category_objects = get_the_category($loop_id);
    foreach($loop_category_objects as $cd){
        $loop_category_name = $cd->cat_name;
        break;
    }
    $loop_permalink = get_the_permalink($loop_id);
    $loop_thumb_url = get_thumb_url($loop_id);
?>
                    <a class="top_news_tp" href="<?php echo $loop_permalink; ?>">
                        <div class="news_imgtitle">
                            <div class="news_img">
                                <img src="<?php echo $loop_thumb_url; ?>">
                            </div>
                            <div class="newsitem_title">
                                <h3><?php echo $loop_title; ?></h3>
                            </div>
                        </div>
                        <div class="news_daterow">
                            <div class="news_date"><?php echo $loop_date; ?></div>
                            <div class="news_cat"><?php echo $loop_category_name; ?></div>
                        </div>
                    </a>
<?php
}
?>                    
                    <div class="news_right_tp">
<?php
for($i=1;$i<count($tpnews_ids);$i++) {
    $loop_id = $tpnews_ids[$i];
    $loop_title = get_the_title();
    $loop_content = get_the_excerpt();
    $loop_date = get_the_date('Y.m.d');
    $loop_category_name = "";
    $loop_category_objects = get_the_category($loop_id);
    foreach($loop_category_objects as $cd){
        $loop_category_name = $cd->cat_name;
        break;
    }
    $loop_permalink = get_the_permalink($loop_id);
    $loop_thumb_url = get_thumb_url($loop_id);
?>                        
                        <div class="news_item_tp" href="<?php echo $loop_permalink; ?>">
                            <div class="news_imgtitle">
                                <div class="news_img">
                                    <img src="<?php echo $loop_thumb_url; ?>">
                                </div>
                                <div class="newsitem_title">
                                    <h3><?php echo $loop_title; ?></h3>
                                </div>
                            </div>
                            <div class="news_daterow">
                                <div class="news_date"><?php echo $loop_date; ?></div>
                                <div class="news_cat"><?php echo $loop_category_name; ?></div>
                            </div>
                        </div>
<?php
}
?>                        
                    </div>
                </div>
                <div class="hx3 block_sp"></div>
                <div class="news_btn_tp flex_sp">
                    <a class="com_job_btn" href="<?php echo get_site_url(); ?>/news/">
                        <span>MORE</span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="6.683" height="10.538" viewBox="0 0 6.683 10.538">
                            <path d="M62.651,13.834,67.212,18.4l-4.562,4.562" transform="translate(-61.944 -13.127)" fill="none" stroke-width="2"/>
                        </svg>                              
                    </a>
                </div>
                <div class="hx4"></div>
            </div>
        </div>
        <div class="reporting_block_tp">
            <div class="poker_cwidth">
                <div class="hx4"></div>
                <div class="reporting_title_tp">
                    <div class="common_title_hp">
                        <div class="X_deco"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/common_title_deco.svg"></div>
                        <h2>Live Reporting</h2>
                    </div>
                </div>
                <div class="titline_btn flex_pc">
                    <a class="com_job_btn" href="<?php echo get_site_url(); ?>/live-reporting/">
                        <span>MORE</span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="6.683" height="10.538" viewBox="0 0 6.683 10.538">
                            <path d="M62.651,13.834,67.212,18.4l-4.562,4.562" transform="translate(-61.944 -13.127)" fill="none" stroke-width="2"/>
                        </svg>                              
                    </a>  
                </div>
                <div class="hx2"></div>
                <div class="event_list_tp">
<?php
$reporting_query = new WP_Query(array(
    'post_type' => 'reporting',
    'paged' => get_query_var('paged'),
    'order'=>'DESC',
    'orderby'=>'meta_value',
    'meta_key'=>'start_event_date',
));
$event_ids = [];
$reporting_list = [];
if ( $reporting_query->have_posts() ) :
    while ( $reporting_query->have_posts() ) :
        $reporting_query->the_post();
        // $new_date_format = date('Y-m-d H:i:s', strtotime('2008-07-01T22:35:17.02'));
        // echo get_field('start_event_date', get_the_ID())." : ".date( 'Ymdhis' )." : ".get_field('end_event_date', get_the_ID())."<br><br><br>";
        $loop_id = get_the_id();
        $loop_event_id = get_field('tournament');
        for($i=0;$i<count($event_ids);$i++) {
            if($loop_event_id == $event_ids[$i]) {
                array_push($reporting_list[$i], $loop_id);
            }
        }
        if(!in_array($loop_event_id, $event_ids)) {
            $reporting_ids = array($loop_id);
            array_push($reporting_list, $reporting_ids);
            array_push($event_ids, $loop_event_id);
        }
    endwhile;
endif;
for($i=0;$i<count($event_ids);$i++) {
        $loop_id = $event_ids[$i];
        $loop_game_id = get_field('game', $loop_id);
        $loop_banner = get_field('banner', $loop_id);
        if(empty($loop_banner)) {
            $loop_banner = get_field('background', $loop_game_id);
        }
        $loop_title = get_the_title($loop_id);
        $loop_permalink = get_the_permalink($loop_id);
        $loop_thumb_url = get_thumb_url($loop_id);
        $loop_start_event_date = date('Y.m.d', strtotime(get_field('start_event_date', $loop_id)));
        $loop_end_event_date = date('Y.m.d', strtotime(get_field('end_event_date', $loop_id)));
        $loop_ptype = 0; //live
        if(strtotime("now") > strtotime(get_field('end_event_date', $loop_id))) {
            $loop_ptype = -1;
        } else if(strtotime("now") < strtotime(get_field('start_event_date', $loop_id))) {
            $loop_ptype = 1;
        }
?>                    
                    <div class="event_report">
                        <a class="event_item" href="<?php echo $loop_permalink; ?>">
                            <div class="eventem_img"><img src="<?php echo $loop_banner; ?>"></div>
                            <div class="eventem_content">
                                <div class="eventem_title"><?php echo $loop_title; ?></div>
                                <div class="eventem_pdate">
                                    <?php
                                        if($loop_ptype == 0) {
                                            echo '<div class="eventem_ptype">LIVE</div>';
                                        } else if($loop_ptype > 0) {
                                            echo '<div class="eventem_ptype X_upcoming">Upcoming</div>';
                                        } else if($loop_ptype < 0) {
                                            echo '<div class="eventem_ptype X_finished">Finished</div>';
                                        }
                                    ?>
                                    <div class="eventem_date"><?php echo $loop_start_event_date.' ~ '.$loop_end_event_date; ?></div>
                                </div>
                            </div>
                        </a>
<?php
    for($j=0;$j<count($reporting_list[$i]);$j++) {
        $report_id = $reporting_list[$i][$j];
        $report_title = get_the_title($report_id);
        $report_permalink = get_the_permalink($report_id);
?>
                        <div class="report_dash"></div>
                        <a class="under_report" href="<?php echo $report_permalink; ?>">
                            <span class="undereport_cap">Live Reporting:</span>
                            <span class="undereport_text"><?php echo $report_title; ?></span>
                        </a>
<?php
    }
?>
                    </div>
<?php
}
?>
                </div>
                <div class="reporting_btn_tp block_sp">
                    <div class="news_btn_tp">
                        <a class="com_job_btn" href="http://192.168.1.31/pokernews/wp1/live-reporting/">
                            <span>MORE</span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="6.683" height="10.538" viewBox="0 0 6.683 10.538">
                                <path d="M62.651,13.834,67.212,18.4l-4.562,4.562" transform="translate(-61.944 -13.127)" fill="none" stroke-width="2"></path>
                            </svg>                              
                        </a>
                    </div>
                </div>
                <div class="hx2"></div>
            </div>
        </div>
        <div class="event_block_tp">
            <div class="poker_cwidth">
                <div class="hx2"></div>
                <div class="event_title_tp">
                    <div class="common_title_hp">
                        <div class="X_deco"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/common_title_deco.svg"></div> 
                        <h2>Live Events</h2> 
                    </div>
                </div>
                <div class="titline_btn flex_pc">
                    <a class="com_job_btn" href="<?php echo get_site_url(); ?>/live-events/">
                        <span>MORE</span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="6.683" height="10.538" viewBox="0 0 6.683 10.538">
                            <path d="M62.651,13.834,67.212,18.4l-4.562,4.562" transform="translate(-61.944 -13.127)" fill="none" stroke-width="2"/>
                        </svg>                              
                    </a>  
                </div>
                <div class="hx2"></div>
                <div class="tabg">
                    <div class="tabg_wrap">
                        <a class="tabg_item pxt_active" href="#">Ongoing</a>
                        <a class="tabg_item" href="<?php echo get_site_url(); ?>/events-upcoming/">Upcoming</a> 
                        <a class="tabg_item" href="<?php echo get_site_url(); ?>/events-past/">Past Events</a> 
                    </div>
                </div>
                <div class="hx2"></div>
                <div class="event_list_tp">
<?php
$event_query = new WP_Query(array(
    'post_type' => 'tournament',
    'paged' => get_query_var('paged'),
    'order'=>'DESC',
    'orderby'=>'meta_value',
    'meta_key'=>'start_event_date',
    'meta_query' => array(
        'relation' => 'AND',
        array(
            'key' => 'start_event_date',
            'value' => date( 'Ymdhis' ),
            'compare' => '<=',
            'type' => 'DATE'
        ),
        array(
            'key' => 'end_event_date',
            'value' => date( 'Ymdhis' ),
            'compare' => '>',
            'type' => 'DATE'
        ),
        array(
            'key' => 'start_event_date',
            'compare' => 'EXISTS',
        ),
    )
));
$event_ids = [];
if ( $event_query->have_posts() ) :
    while ( $event_query->have_posts() ) :
        $event_query->the_post();
        // $new_date_format = date('Y-m-d H:i:s', strtotime('2008-07-01T22:35:17.02'));
        // echo get_field('start_event_date', get_the_ID())." : ".date( 'Ymdhis' )." : ".get_field('end_event_date', get_the_ID())."<br><br><br>";
        $loop_id = get_the_id();
        array_push($event_ids, $loop_id);
    endwhile;
endif;
$reporting_list = [];
for($i=0;$i<count($event_ids);$i++) {
    $event_id = $event_ids[$i];
    $query = new WP_Query(array(
        'post_type' => 'reporting',
        'posts_per_page' => -1, 
        'meta_query' => array(
            'relation' => 'AND',
            array(
                'key' => 'tournament',
                'value' => $event_id,
                'compare' => '='
            )
        )
    ));
    $reporting_ids = [];
    if ( $query->have_posts() ) :
        while ( $query->have_posts() ) :
            $query->the_post();
            $loop_id = get_the_id();
            array_push($reporting_ids, $loop_id);
        endwhile;
    endif;
    array_push($reporting_list, $reporting_ids);
}
for($i=0;$i<count($event_ids);$i++) {
        $loop_id = $event_ids[$i];
        $loop_game_id = get_field('game', $loop_id);
        $loop_banner = get_field('banner', $loop_id);
        if(empty($loop_banner)) {
            $loop_banner = get_field('background', $loop_game_id);
        }
        $loop_title = get_the_title($loop_id);
        $loop_permalink = get_the_permalink($loop_id);
        $loop_thumb_url = get_thumb_url($loop_id);
        $loop_start_event_date = date('Y.m.d', strtotime(get_field('start_event_date', $loop_id)));
        $loop_end_event_date = date('Y.m.d', strtotime(get_field('end_event_date', $loop_id)));
?>                    
                    <div class="event_report">
                        <a class="event_item" href="<?php echo $loop_permalink; ?>">
                            <div class="eventem_img"><img src="<?php echo $loop_banner; ?>"></div>
                            <div class="eventem_content">
                                <div class="eventem_title"><?php echo $loop_title; ?></div>
                                <div class="eventem_pdate">
                                    <div class="eventem_ptype">LIVE</div>
                                    <div class="eventem_date"><?php echo $loop_start_event_date.' ~ '.$loop_end_event_date; ?></div>
                                </div>
                            </div>
                        </a>
<?php
    for($j=0;$j<count($reporting_list[$i]);$j++) {
        $report_id = $reporting_list[$i][$j];
        $report_title = get_the_title($report_id);
        $report_permalink = get_the_permalink($report_id);
?>
                        <div class="report_dash"></div>
                        <a class="under_report" href="<?php echo $report_permalink; ?>">
                            <span class="undereport_cap">Live Reporting:</span>
                            <span class="undereport_text"><?php echo $report_title; ?></span>
                        </a>
<?php
    }
?>
                    </div>
<?php
}
?>
                    
                </div>
                <div class="event_btn_tp block_sp">
                    <div class="news_btn_tp">
                        <a class="com_job_btn" href="http://192.168.1.31/pokernews/wp1/live-events/">
                            <span>MORE</span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="6.683" height="10.538" viewBox="0 0 6.683 10.538">
                                <path d="M62.651,13.834,67.212,18.4l-4.562,4.562" transform="translate(-61.944 -13.127)" fill="none" stroke-width="2"></path>
                            </svg>                              
                        </a>
                    </div>
                </div>
                <div class="hx4"></div>
            </div>
        </div>
        <div class="gallery_block_tp">
            <div class="poker_cwidth">
                <div class="hx4"></div>
                <div class="gallery_title_tp">
                    <div class="common_title_hp">
                        <div class="X_deco"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/common_title_deco1.svg"></div>                                    
                        <h2>Gallery</h2> 
                    </div>
                </div>
                <div class="titline_btn flex_pc">
                    <div class="gallery_btn_tp">
                        <a class="com_job_btn" href="<?php echo get_site_url(); ?>/live-reporting/">
                            <span>MORE</span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="6.683" height="10.538" viewBox="0 0 6.683 10.538">
                                <path d="M62.651,13.834,67.212,18.4l-4.562,4.562" transform="translate(-61.944 -13.127)" fill="none" stroke-width="2"/>
                            </svg>                              
                        </a>      
                    </div>
                </div>
                <div class="hx2"></div>
                <div class="gallery_row_tp">
<?php
$gallery_query = new WP_Query(array(
    'post_type' => 'gallery',
));
if ( $gallery_query->have_posts() ) :
    while ( $gallery_query->have_posts() ) :
        $gallery_query->the_post();
        $loop_id = get_the_id();
        $loop_title = get_the_title();
        $loop_content = get_the_excerpt();
        $loop_date = get_the_date('Y.m.d');
        $loop_category_name = "";
        $loop_category_objects = get_the_category($loop_id);
        foreach($loop_category_objects as $cd){
            $loop_category_name = $cd->cat_name;
            break;
        }
        $loop_permalink = get_the_permalink($loop_id);
        $loop_thumb_url = get_thumb_url($loop_id);
?>                     
                    <a class="gallery_item" href="<?php echo $loop_permalink; ?>">
                        <div class="galitem_img">
                            <img src="<?php echo $loop_thumb_url; ?>">
                            <div class="galitem_title"><?php echo $loop_title; ?></div>
                        </div>
                    </a>
<?php
    endwhile;
endif;	
?>
                </div>
                <div class="gallery_btn_tp flex_sp">
                    <a class="com_job_btn" href="#">
                        <span>MORE</span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="6.683" height="10.538" viewBox="0 0 6.683 10.538">
                            <path d="M62.651,13.834,67.212,18.4l-4.562,4.562" transform="translate(-61.944 -13.127)" fill="none" stroke-width="2"></path>
                        </svg>
                    </a>
                </div>
                <div class="hx4"></div>
            </div>
        </div>
        <div class="poker_contact">
            <div class="poker_cwidth">
                <div class="hx4"></div>
                <div class="ranking_row_tp">
                    <a class="ranking_btn_tp" href="<?php echo get_site_url(); ?>/ranking/">
                        <div class="ranking_img_tp"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/tp_ranking.jpg"></div>
                        <div class="ranking_text_tp">
                            <span>RANKING</span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="19.914" height="19.602" viewBox="0 0 19.914 19.602">
                                <g transform="translate(-769.867 -4160.793)">
                                    <path d="M779.273,4161.534l9.094,9.094-9.094,9.094" transform="translate(0 -0.034)" fill="none" stroke="#fff" stroke-width="2"/>
                                    <line x2="18.5" transform="translate(769.867 4170.594)" fill="none" stroke="#fff" stroke-width="2"/>
                                </g>
                            </svg>
                        </div>
                    </a>
                    <a class="ranking_btn_tp" href="<?php echo get_site_url(); ?>/contact/">
                        <div class="ranking_img_tp"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/tp_contact.jpg"></div>
                        <div class="ranking_text_tp">
                            <span>CONTACT</span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="19.914" height="19.602" viewBox="0 0 19.914 19.602">
                                <g transform="translate(-769.867 -4160.793)">
                                    <path d="M779.273,4161.534l9.094,9.094-9.094,9.094" transform="translate(0 -0.034)" fill="none" stroke="#fff" stroke-width="2"/>
                                    <line x2="18.5" transform="translate(769.867 4170.594)" fill="none" stroke="#fff" stroke-width="2"/>
                                </g>
                            </svg>
                        </div>
                    </a>
                </div>
                <div class="hx4"></div>
            </div>
        </div>
    </div>
</section>
<!-- CONTAIN_END -->
<?php
get_footer();
