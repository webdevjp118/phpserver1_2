<div class="topmenu_area block_pc">
    <div class="poker_width">
        <div class="topmenu_block">
            <div class="poker_cwidth">
                <div class="top_menu">
                    <a class="topmenu_a" href="<?php echo get_site_url(); ?>/news/">
                        <div class="topmenu_shape">
                            <div class="topmenu_cap">NEWS</div>
                            <div class="topmenu_uline"></div>
                        </div>
                    </a>
                    <a class="topmenu_a" href="<?php echo get_site_url(); ?>/live-reporting/">
                        <div class="topmenu_shape">
                            <div class="topmenu_cap">LIVE REPORTING</div>
                            <div class="topmenu_uline"></div>
                        </div>
                    </a>
                    <a class="topmenu_a" href="<?php echo get_site_url(); ?>/live-events/">
                        <div class="topmenu_shape">
                            <div class="topmenu_cap">LIVE EVENTS</div>
                            <div class="topmenu_uline"></div>
                        </div>
                    </a>
                    <a class="topmenu_a" href="<?php echo get_site_url(); ?>/gallery/">
                        <div class="topmenu_shape">
                            <div class="topmenu_cap">GALLERY</div>
                            <div class="topmenu_uline"></div>
                        </div>
                    </a>
                    <a class="topmenu_a" href="<?php echo get_site_url(); ?>/ranking/">
                        <div class="topmenu_shape">
                            <div class="topmenu_cap">RANKING</div>
                            <div class="topmenu_uline"></div>
                        </div>
                    </a>
                    <a class="topmenu_a" href="<?php echo get_site_url(); ?>/contact/">
                        <div class="topmenu_shape">
                            <div class="topmenu_cap">CONTACT</div>
                            <div class="topmenu_uline"></div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>