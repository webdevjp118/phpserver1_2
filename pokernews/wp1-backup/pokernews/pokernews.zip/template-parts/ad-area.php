<div class="ad_area">
    <div class="poker_width">
        <div class="instead_head"></div>
        <div class="gto_block">
            <div class="top_ad">
                <a href="#">
                    <img class="block_pc" src="<?php echo get_stylesheet_directory_uri(); ?>/images/gto_adpc.png">
                    <img class="block_sp" src="<?php echo get_stylesheet_directory_uri(); ?>/images/gto_adsp.jpg">
                </a>
            </div>
        </div>
        <div class="top_logo">
            <a href="#"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/logo_silver.png"></a>
        </div>
        <div class="direct_block block_pc">
            <a class="direct_events" href="<?php echo get_site_url(); ?>/live-events/">
                <div class="live_redcap_tp">LIVE EVENTS</div>
                <?php
                    $tpevents = get_top_events();
                    if(count($tpevents) > 0) {
                        echo '<div class="live_cur_tp">'.get_the_title($tpevents[0]).'</div>';
                    }                      
                ?>
            </a>
        </div>
    </div>
</div>