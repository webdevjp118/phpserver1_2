<?php
get_header();
global $wp_query;
$query = $wp_query;
?>
<?php
if ( $query->have_posts() ) :
    while ( $query->have_posts() ) :
        $query->the_post();
        $loop_id = get_the_id();
        $loop_info = get_field('info');
        $loop_game_id = get_field('game');
        $loop_banner = get_field('banner');
        $loop_sign = get_field('sign', $loop_game_id);
        $loop_game_name = get_the_title($loop_game_id);
        if(empty($loop_banner)) {
            $loop_banner = get_field('background', $loop_game_id);
        }
        $loop_title = get_the_title();
        $loop_content = get_the_excerpt();
        $loop_date = get_the_date('Y.m.d');
        $loop_category_name = "";
        $loop_category_objects = get_the_category($loop_id);
        foreach($loop_category_objects as $cd){
            $loop_category_name = $cd->cat_name;
            break;
        }
        $loop_permalink = get_the_permalink($loop_id);
        $loop_thumb_url = get_thumb_url($loop_id);
    endwhile;
endif;
?> 
<!-- CONTAIN_START -->
<?php get_template_part('template-parts/background-ad'); ?>
<section id="contain" class="content_section">
    <?php get_template_part('template-parts/ad-area'); ?>
    <div class="poker_width">
        <div class="page_content">
            <div class="poker_cwidth">
                <?php get_template_part('template-parts/top-menu'); ?>
                <div class="pline1"></div>
                <div class="hx5"></div>
                <div class="tour_game" style="background-image: url(<?php echo $loop_banner; ?>);">
                    <h1 class="main_title"><?php echo $loop_title; ?></h1>
                    <div class="hx2"></div>
                    <div class="tour_content">
                        <?php echo $loop_info; ?>
                    </div>
                    <a class="tourgame_sign" href="#">
                        <img src="<?php echo $loop_sign; ?>" alt="888poker LIVE">
                        <span><?php echo $loop_game_name; ?></span>
                    </a>
                </div>
                <div class="hx8"></div>
                <div class="schedule_block">
                    <?php the_content(); ?>
                </div>
                <div class="hx6"></div>
            </div>
            <div class="side_news">
                <div class="poker_cwidth">
                    <div class="hx4"></div>
                    <div class="sidenews_title">
                        <div class="common_title_hp">
                            <p><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/common_title_deco.svg"></p>                                    
                            <h2>Related Articles</h2> 
                        </div>
                    </div>
                    <div class="hx3"></div>
                    <div class="sidenews_row">
                        <div class="sidenews_item">
                            <div class="news_imgtitle">
                                <div class="news_img">
                                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/news02.jpg">
                                </div>
                                <div class="newsitem_title">
                                    <h3>ここにタイトルテキストがあります。ここにタイトルテキストがあります。ここにタイトルテキストがあります。</h3>
                                </div>
                            </div>
                            <div class="news_daterow">
                                <div class="news_date">2023.7.18</div>
                                <div class="news_cat">WSOP</div>
                            </div>
                        </div>
                        <div class="sidenews_item">
                            <div class="news_imgtitle">
                                <div class="news_img">
                                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/news02.jpg">
                                </div>
                                <div class="newsitem_title">
                                    <h3>ここにタイトルテキストがあります。ここにタイトルテキストがあります。ここにタイトルテキストがあります。</h3>
                                </div>
                            </div>
                            <div class="news_daterow">
                                <div class="news_date">2023.7.18</div>
                                <div class="news_cat">WSOP</div>
                            </div>
                        </div>
                        <div class="sidenews_item">
                            <div class="news_imgtitle">
                                <div class="news_img">
                                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/news02.jpg">
                                </div>
                                <div class="newsitem_title">
                                    <h3>ここにタイトルテキストがあります。ここにタイトルテキストがあります。ここにタイトルテキストがあります。</h3>
                                </div>
                            </div>
                            <div class="news_daterow">
                                <div class="news_date">2023.7.18</div>
                                <div class="news_cat">WSOP</div>
                            </div>
                        </div>
                    </div>
                    <div class="hx4"></div>
                </div>
            </div>
            <div class="poker_cwidth">
                <div class="hx8"></div>
                <div class="ranking_row_tp">
                    <a class="ranking_btn_tp" href="#">
                        <div class="ranking_img_tp"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/tp_ranking.jpg"></div>
                        <div class="ranking_text_tp">
                            <span>RANKING</span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="19.914" height="19.602" viewBox="0 0 19.914 19.602">
                                <g transform="translate(-769.867 -4160.793)">
                                  <path d="M779.273,4161.534l9.094,9.094-9.094,9.094" transform="translate(0 -0.034)" fill="none" stroke="#fff" stroke-width="2"/>
                                  <line x2="18.5" transform="translate(769.867 4170.594)" fill="none" stroke="#fff" stroke-width="2"/>
                                </g>
                            </svg>
                        </div>
                    </a>
                    <a class="ranking_btn_tp" href="#">
                        <div class="ranking_img_tp"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/tp_contact.jpg"></div>
                        <div class="ranking_text_tp">
                            <span>CONTACT</span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="19.914" height="19.602" viewBox="0 0 19.914 19.602">
                                <g transform="translate(-769.867 -4160.793)">
                                  <path d="M779.273,4161.534l9.094,9.094-9.094,9.094" transform="translate(0 -0.034)" fill="none" stroke="#fff" stroke-width="2"/>
                                  <line x2="18.5" transform="translate(769.867 4170.594)" fill="none" stroke="#fff" stroke-width="2"/>
                                </g>
                            </svg>
                        </div>
                    </a>
                </div>
                <div class="hx4"></div>
            </div>
        </div>
    </div>
</div>
<?php
get_footer();
