<?php
get_header();
?>
<main>
  <section class="privacypolicy">
    <div class="privacypolicy_wraper" style="height:45vh; padding-top: 100px">
      <p style="text-align: center">
      Failed
      </p>
    </div>
  </section>
</main>
<?php
<?php
get_footer();
