<?php
get_header();
?>
<main>
  <section class="privacypolicy">
  <div class="privacypolicy_wraper" style="height:45vh; padding-top: 100px">
      <p style="text-align: center">
        Success
      </p>
    </div>
  </section>
</main>
<?php
get_footer();
