//mailform pro extension javascript ver2.1.3
function MFP_EX_ONLOAD(obj){
	
}
function MFP_EX_ELEMENT_CHECK(obj){
	
}
function MFP_EX_SUBMIT(obj){
	
}
function MFP_CHECK_EXTENSION(){
	
}