
var mfp_lang = "ja";

var mfp_langObj = new Object();
mfp_langObj["ja"] = new Object();
mfp_langObj["ja"][0] = "確認用メールアドレスとメールアドレスが一致しません。";
mfp_langObj["ja"][1] = "確認用メールアドレスが未入力です。";
mfp_langObj["ja"][2] = "メールアドレスが未入力です。";
mfp_langObj["ja"][3] = "メールアドレスが正しくありません。";
mfp_langObj["ja"][4] = "が未入力です。";
mfp_langObj["ja"][5] = "が<CNT>個以上チェックされていません。";
mfp_langObj["ja"][6] = "がチェックされていません。";
mfp_langObj["ja"][7] = "が選択されていません。";
mfp_langObj["ja"][8] = "送信してもよろしいですか？";
mfp_langObj["ja"][9] = "入力内容に以下の不備があります";
mfp_langObj["ja"][10] = "代金";
mfp_langObj["ja"][11] = "円";
mfp_langObj["ja"][12] = "メールアドレス";
mfp_langObj["ja"][13] = "入力内容がすべて消去されますがよろしいですか";
mfp_langObj["ja"][14] = "は対応していないファイルが選択されています";

mfp_langObj["en"] = new Object();
mfp_langObj["en"][0] = "Re-entered E-mail address and E-mail address was not matched.";
mfp_langObj["en"][1] = "Please input the re-enter E-mail address.";
mfp_langObj["en"][2] = "Please enter E-mail address";
mfp_langObj["en"][3] = "The E-mail address is not correct.";
mfp_langObj["en"][4] = " is not input.";
mfp_langObj["en"][5] = " has not been checked more than <CNT>";
mfp_langObj["en"][6] = " has not been checked.";
mfp_langObj["en"][7] = " has not been selected.";
mfp_langObj["en"][8] = "Can it be sent?";
mfp_langObj["en"][9] = "There is an inappropriate input as below.";
mfp_langObj["en"][10] = "Price";
mfp_langObj["en"][11] = "YEN";
mfp_langObj["en"][12] = "E-Mail Address";
mfp_langObj["en"][13] = "Is it good though all content of the input is deleted ?";
mfp_langObj["en"][14] = " is a file that doesn't correspond.";
