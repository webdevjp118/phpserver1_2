var mfp_version = "3.0.0";
var mfp_lastupdate = "2011-04-01 00:00:00";
document.write(mfp_version);