<?php
get_header();
?>

<div style="width: 100%; height: 100vh; display: flex; justify-content: center; align-items: center;">
    <p>Failed</p>
</div>

<?php
get_footer();
