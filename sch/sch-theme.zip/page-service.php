<?php
get_header();
?>

<section id="contain">    	        
    <div class="banner_block_hp">             
        <div class="banner_inner_hp" style="position:relative">         
            <div class="fading-wrapper">
                <div class="pic-1" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/images/banner_1.png)"></div>
                <div class="pic-2" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/images/banner_2.png)"></div>
                <div class="pic-3" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/images/banner_3.png)"></div>
                <div class="pic-4" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/images/banner_4.png)"></div>
            </div> 
            <div class="blue-mask"></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 banner_block_in_hp">                    	
                        <div class="banner_middle_hp"> 
                            <div class="banner_title_hp" data-aos="fade-right" >		     
                                <h1>サービス</h1>
                                <h2>Service</h2>
                            </div>
                        </div>                                               
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>            
        </div>
        <div class="clearfix"></div>
    </div>
    <div class="companies_block_hp">             
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 companies_block_in_hp"> 
                    <div class="common_title_hp" data-aos="fade-right">                   	
                        <h2>人材をお探しの企業様</h2>
                        <p>「働きたい方｣ 「サービスを利用したい企業様」 に最速で人材をマッチング人事・経理・管理等の業務が一切不要となり、 企業様の時間ロスが軽減できます</p>
                    </div>
                    <div class="companies_middle_hp" data-aos="fade-up"> 
                        <div class="companies_title_hp">
                            <h2>人材を導入するメリット</h2>
                        </div>
                        <div class="companies_top_hp">  
                            <div class="companies_info_hp">                            	 
                                「働きたい方｣ 「サービスを利用したい企業様」 <span>に最速で人材をマッチング</span><br/>
                                人事・経理・管理等の業務が一切不要<span>となり、</span> 企業様の時間ロスが軽減<span>できます</span>
                            </div>
                            <div class="companies_img_hp">
                                <a href="#">
                                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/companies_img1.svg" alt="" />
                                </a>    
                            </div>
                            <div class="companies_boxes_hp">
                            <div class="companies_box_hp" data-aos="fade-up">
                                <a href="#">
                                    <div class="companies_box_num_hp">
                                        <div class="companies_num_hp">
                                            1
                                        </div>
                                    </div>
                                    <div class="companies_box_in_hp">
                                        <div class="companies_box_img_hp">
                                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/companies_img2.svg" alt="" />
                                        </div>
                                        <h2>固定費の削減</h2>
                                        <p>人材不足に早急に対応可能。「人手が足りない…」など突発的に人が必要な前日でも、単発のお仕事を自由に発注いただけます。通年ではなくスポットでお手伝い可能です</p>
                                    </div>
                                </a>    
                            </div>
                            <div class="companies_box_hp" data-aos="fade-up">
                                <a href="#">
                                    <div class="companies_box_num_hp">
                                        <div class="companies_num_hp">
                                            2
                                        </div>
                                    </div>
                                    <div class="companies_box_in_hp">
                                        <div class="companies_box_img_hp">
                                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/companies_img3.svg" alt="" />
                                        </div>
                                        <h2>採用時のコストの削減</h2>
                                        <p>採用・応募者の管理・給与支払いまで、すべて当社が担当。 コストはもちろん時間や手間暇をかけずにご依頼が可能です</p>
                                    </div>
                                </a>
                            </div>
                            <div class="companies_box_hp" data-aos="fade-up">
                                <a href="#">
                                    <div class="companies_box_num_hp">
                                        <div class="companies_num_hp">
                                            3
                                        </div>
                                    </div>
                                    <div class="companies_box_in_hp">
                                        <div class="companies_box_img_hp">
                                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/companies_img4.svg" alt="" />
                                        </div>
                                        <h2>全国各地でアルバイトの手配が可能</h2>
                                        <p>前日の15時までにご依頼いただければ、どんなご要望にも全力でお応えします</p>
                                    </div>
                                </a>
                            </div>                       
                        </div>
                        </div>
                    </div>                                               
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>            
        <div class="clearfix"></div>
    </div>
    <div class="about_block_hp">             
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 about_block_in_hp">                     	
                    <div class="about_middle_hp"> 
                        <div class="companies_title_hp" data-aos="fade-up">
                            <h2>サービス内容について</h2>
                        </div>
                        <div class="about_top_hp">
                            <div class="about_step_hp" data-aos="fade-up">
                                <div class="about_step_num_hp">
                                    01
                                </div>
                                <div class="about_step_title_hp">
                                    短期人材サービス
                                </div>
                            </div>
                            <div class="about_title_hp" data-aos="fade-up">
                                <h2>「必要な時に必要なだけ、人手を借りたい」</h2>
                                <p>たとえ急なご依頼でも、人員不足ニーズにお応えします！</p>
                            </div>
                            <div class="about_img_hp" data-aos="fade-up">
                                <a href="#">
                                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/about_img2.png" alt="" />
                                </a>    
                            </div>
                            <div class="about_grid_hp">
                                <div class="about_left_hp" data-aos="fade-right">
                                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/about_img.png" alt="" />
                                </div>
                                <div class="about_right_hp">
                                    <div class="about_right_boxes_hp">
                                        <div class="about_right_box_hp" data-aos="fade-left">
                                            <a href="#">
                                                <div class="about_right_box_img_hp">
                                                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/years_1.svg" alt="" />
                                                </div>
                                                <div class="about_right_box_info_hp">
                                                    1日3時時間らOK！
                                                </div>
                                            </a>
                                        </div>
                                        <div class="about_right_box_hp" data-aos="fade-left">
                                            <a href="#">
                                                <div class="about_right_box_img_hp">
                                                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/years_2.svg" alt="" />
                                                </div>
                                                <div class="about_right_box_info_hp">
                                                    前日の15時まで受付可能！
                                                </div>
                                            </a>
                                        </div>
                                        <div class="about_right_box_hp" data-aos="fade-left">
                                            <a href="#">
                                                <div class="about_right_box_img_hp">
                                                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/years_3.svg" alt="" />
                                                </div>
                                                <div class="about_right_box_info_hp">
                                                    365日体制で人員を確保！
                                                </div>
                                            </a>
                                        </div>                                            
                                    </div>
                                </div>
                            </div>
                            <div class="about_boxes_hp" data-aos="fade-up">
                                <div class="about_box_title_hp">
                                        <h3>業務内容</h3>
                                    </div>
                                <div class="about_box_hp">                                    	
                                    <div class="about_left_grid_hp">
                                        <div class="about_left_title_hp">
                                            <h3>イベント関連</h3>
                                            <p>コンサートステージの設営・撤去</p>
                                            <p>競馬場のテント設営・撤去</p>
                                            <p>展示会のブース設営・撤去</p>
                                            <p>サッカー公式試合の受付・会場案内</p>
                                            <p>季節のイベント装飾 ・運営</p>
                                            <p>大手電機メーカーのイベントスタッフ</p>
                                            <p>地域のお祭りのやぐら設営</p>
                                        </div>
                                    </div>
                                    <div class="about_right_img_hp">
                                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/about_img3.png" alt="" />
                                    </div>
                                </div>
                                <div class="about_bottom_box_hp">
                                    <div class="about_left_title_hp">
                                        <h3>物流関連</h3>
                                        <p>大手電機メーカーの商品の検品</p>
                                        <p>電子機器へのシール貼り</p>
                                    </div>
                                    <div class="about_left_title_hp">
                                        <h3>運搬関連</h3>
                                        <p>高層ビルの事務所移転</p>
                                        <p>大手研修センターへの家具の搬出入</p>
                                        <p>催事場での什器の搬出入</p>
                                    </div>
                                    <div class="about_left_title_hp">
                                        <h3>内装施工関連</h3>
                                        <p>ファッションビルの装飾撤去</p>
                                        <p>大手百貨店の内装施工</p>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>                                               
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>            
        <div class="clearfix"></div>
    </div>    
    <div class="service_block_hp" data-aos="fade-up">             
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 service_block_in_hp">                     	
                    <div class="service_middle_hp">                         	
                        <div class="service_top_hp">
                            <div class="about_step_hp">
                                <div class="about_step_num_hp">
                                    02
                                </div>
                                <div class="about_step_title_hp">
                                    短期人材サービス
                                </div>
                            </div>
                            <div class="about_title_hp service_pd_hp">
                                <h2>初期コスト０で採用可能</h2>
                                <p>実際の体験を取り入れることで一番雇用に必要とされる情報が手に入ります。</p>
                            </div>
                            <div class="service_title_hp">                             
                                <h4>お問い合せから採用までの流れ</h4>
                            </div>
                            <div class="service_grid_hp">
                                <div class="service_left_hp">
                                    <div class="service_left_img_hp">
                                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/service_svg1.svg" alt="" />
                                    </div>
                                    <div class="service_left_img_hp">
                                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/service_svg2.svg" alt="" />
                                    </div>
                                    <div class="service_left_img_hp">
                                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/service_svg3.svg" alt="" />
                                    </div>
                                    <div class="service_left_img_hp">
                                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/service_svg4.svg" alt="" />
                                    </div>
                                    <div class="service_left_img_hp">
                                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/service_svg5.svg" alt="" />
                                    </div>
                                    <div class="service_left_img_hp">
                                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/service_svg6.svg" alt="" />
                                    </div>
                                    <div class="service_left_img_hp">
                                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/service_svg7.svg" alt="" />
                                    </div>
                                </div>
                                <div class="service_right_hp">
                                    <div class="service_right_in_hp">
                                        <div class="service_number_hp">
                                            <div class="service_num_hp">
                                                1
                                            </div>
                                            <div class="service_subtitle_hp">
                                                お問い合せ
                                            </div>
                                        </div>
                                        <div class="service_info_hp">
                                            まずはお問い合せして頂きます。
                                        </div>
                                    </div>
                                    <div class="service_right_in_hp">
                                        <div class="service_number_hp">
                                            <div class="service_num_hp">
                                                2
                                            </div>
                                            <div class="service_subtitle_hp">
                                                    ご説明ヒアリング
                                            </div>
                                        </div>
                                        <div class="service_info_hp">
                                            希望職種のヒアリングを行い、職場実習前に必要な研修を実施。
                                        </div>
                                    </div>
                                    <div class="service_right_in_hp">
                                        <div class="service_number_hp">
                                            <div class="service_num_hp">
                                                3
                                            </div>
                                            <div class="service_subtitle_hp">
                                                契約求人登録
                                            </div>
                                        </div>
                                        <div class="service_info_hp">
                                            掲載内容で「職場体験」をテーマにすることで実体験に対してのアテンドを行っていきます。
                                        </div>
                                    </div>
                                    <div class="service_right_in_hp">
                                        <div class="service_number_hp">
                                            <div class="service_num_hp">
                                                4
                                            </div>
                                            <div class="service_subtitle_hp">
                                                ご紹介書類選考
                                            </div>
                                        </div>
                                        <div class="service_info_hp">
                                            まずはお問い合せして頂きます。
                                        </div>
                                    </div>
                                    <div class="service_right_in_hp">
                                        <div class="service_number_hp">
                                            <div class="service_num_hp">
                                                5
                                            </div>
                                            <div class="service_subtitle_hp">
                                                面接
                                            </div>
                                        </div>
                                        <div class="service_info_hp">
                                            上記の流れをもとに面接を行います。
                                        </div>
                                    </div>
                                    <div class="service_right_in_hp">
                                        <div class="service_number_hp">
                                            <div class="service_num_hp">
                                                6
                                            </div>
                                            <div class="service_subtitle_hp">
                                                職場体験
                                            </div>
                                        </div>
                                        <div class="service_info_hp">
                                            「３～５日間」を目安に行い、実際に働く期間で必要とされる情報をヒアリングし確実な採用につなげていきましょう。
                                        </div>
                                    </div>
                                    <div class="service_right_in_hp">
                                        <div class="service_number_hp">
                                            <div class="service_num_hp">
                                                7
                                            </div>
                                            <div class="service_subtitle_hp">
                                                    内定・採用
                                            </div>
                                        </div>
                                        <div class="service_info_hp">
                                            就職後のフォローも万全です。
                                        </div>
                                    </div>                                
                                </div>
                            </div>                                
                        </div>
                    </div>                                               
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>            
        <div class="clearfix"></div>
    </div>
    <div class="job_block_hp" data-aos="fade-up">             
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 job_block_in_hp">  
                    <div class="common_title_hp">                   	
                        <h2>お仕事をお探しの方</h2>
                    </div>                   	
                    <div class="job_middle_hp">  
                        <div class="companies_title_hp">
                            <h2>ご登録の流れ</h2>
                        </div>                       	
                        <div class="job_top_hp">
                            <div class="job_info_hp">                                                     
                                面接や登録会はありません。ネット上から簡単にお手続きいただけます。<br/>
                                登録が完了すれば好きな場所・好きな時間・好きな職種ですぐに働けます。<br/>
                                仕事が終わったら、翌日までにお給料がアプリに反映され、翌日に給料支払いが可能です。
                            </div>
                            <div class="job_box_hp">
                                <div class="job_box_left_hp">  
                                    <div class="job_box_left_in_hp">
                                        簡単<br/><span>５ステップ</span>
                                    </div>
                                </div>
                                <div class="job_box_right_hp">  
                                    <div class="job_box_right_img_hp">
                                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/flow_img.png" alt="" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>                                                                       
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>            
        <div class="clearfix"></div>
    </div>
    <div class="examples_block_hp" data-aos="fade-up">             
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 examples_block_in_hp">                      	                   	
                    <div class="examples_middle_hp">  
                        <div class="companies_title_hp">
                            <h2>業務内容事例</h2>
                        </div>                       	
                        <div class="examples_top_hp">
                            <div class="examples_boxes_hp">
                                <div class="examples_box_hp">
                                    <a href="#">
                                        <div class="examples_img_hp">
                                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/flow_img2.png" alt="" />
                                        </div>
                                        <div class="examples_info_hp">
                                            <h2>タイトルテキストがあります。</h2>
                                            <p>概要テキスト概要テキスト概要テキスト概要テキストがあります。</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="examples_box_hp">
                                    <a href="#">
                                        <div class="examples_img_hp">
                                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/flow_img3.png" alt="" />
                                        </div>
                                        <div class="examples_info_hp">
                                            <h2>タイトルテキストがあります。</h2>
                                            <p>概要テキスト概要テキスト概要テキスト概要テキストがあります。</p>
                                        </div>
                                    </a>    
                                </div>
                                <div class="examples_box_hp">
                                    <a href="#">
                                        <div class="examples_img_hp">
                                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/flow_img4.png" alt="" />
                                        </div>
                                        <div class="examples_info_hp">
                                            <h2>タイトルテキストがあります。</h2>
                                            <p>概要テキスト概要テキスト概要テキスト概要テキストがあります。</p>
                                        </div>
                                    </a>    
                                </div>
                                <div class="examples_box_hp">
                                    <a href="#">
                                        <div class="examples_img_hp">
                                            <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/flow_img5.png" alt="" />
                                        </div>
                                        <div class="examples_info_hp">
                                            <h2>タイトルテキストがあります。</h2>
                                            <p>概要テキスト概要テキスト概要テキスト概要テキストがあります。</p>
                                        </div>
                                    </a>    
                                </div>
                            </div>
                        </div>
                    </div>                                                                       
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>            
        <div class="clearfix"></div>
    </div>
    <div class="register_block_hp" data-aos="fade-up">             
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 register_block_in_hp">                      	                   	
                    <div class="register_middle_hp">  
                        <div class="register_box_hp">       	
                            <a href="#">
                                <div class="register_title_hp">
                                    <h3>ご登録はこちら</h3>
                                </div>
                                <div class="register_arrow_hp">
                                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/arrow.svg" alt="" />
                                </div>
                            </a>
                        </div>
                    </div>                                                                       
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>            
        <div class="clearfix"></div>
    </div>    
</section>

<?php
get_footer();
