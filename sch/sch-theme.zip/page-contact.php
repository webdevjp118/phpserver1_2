<?php
get_header();
?>
<?php
if(isset($_POST['submit-confirm']) && ($_POST['submit-confirm'] == 'submit-confirm')) {

    $field1 = isset($_POST['field1']) ? $_POST['field1']: '';
    $field2 = isset($_POST['field2']) ? $_POST['field2']: '';
    $field3 = isset($_POST['field3']) ? $_POST['field3']: ''; //user email
    $field4 = isset($_POST['field4']) ? $_POST['field4']: '';
    $field5 = isset($_POST['field5']) ? $_POST['field5']: '';
    $field5 = isset($_POST['field6']) ? $_POST['field6']: '';
    
    $to      = 'prgfinal216@gmail.com';
    $from    = $field3;

    $message = "
    お名前 : ".$field1."<br>
    企業名 : ".$field2."<br>
    メールアドレス : ".$field3."<br>
    電話番号 : ".$field4."<br>
    お問合せ内容 : ".$field5."<br>
    概要 : <br>".$field6."<br>
    ";

    $subject = 'Team Building';

    $headers = "From: " . $from . "\r\n";
    $headers .= "Reply-To: " . $from . "\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

    if(mail($to, $subject, $message, $headers)) {
      echo '<script>location.href="'.home_url().'/success"</script>';
    } else {
      echo '<script>location.href="'.home_url().'/failed"</script>';
    }    
}
?>
<section id="contain">    	        
    <div class="banner_block_hp">
        <div class="banner_inner_hp" style="position:relative">         
            <div class="fading-wrapper">
                <div class="pic-1" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/images/banner_1.png)"></div>
                <div class="pic-2" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/images/banner_2.png)"></div>
                <div class="pic-3" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/images/banner_3.png)"></div>
                <div class="pic-4" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/images/banner_4.png)"></div>
            </div> 
            <div class="blue-mask"></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 banner_block_in_hp">                         	                   	
                        <div class="banner_middle_hp"> 
                            <div class="banner_title_hp" data-aos="fade-right">		     
                                <h1>お問い合せ</h1>
                                <h2>Contact</h2>
                            </div>
                        </div>                                               
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>            
        </div>
        <div class="clearfix"></div>
    </div>
    
    <div class="please_block_cp">           	       
        <div class="container">
            <div class="row">
                <form action="" method="post" enctype="multipart/form-data">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 please_block_in_cp">  
                        <div class="common_title_hp common_change_cp please_change_cp">                   	
                            <h2>Contact</h2>                            	
                        </div>                   	
                        <div class="please_middle_cp" data-aos="fade-up">
                            <div class="please_info_cp">
                                下記フォームに必須事項をご入力の上、送信してください。<br />
                                必須の項目は入力必須となります。
                            </div>
                            <div class="contact-form-cop">                                
                                <div class="form-field-cop">
                                    <div class="form-field-lable-cop">名前<span>必須</span></div>                     
                                        <div class="form-field-input-cop"><input type="text" placeholder="例）山田　太郎" name="field1" required></div>                                        
                                    <div class="clearfix"></div>
                                </div>
                                <div class="form-field-cop">
                                    <div class="form-field-lable-cop">企業名</div>                     
                                        <div class="form-field-input-cop"><input type="text" placeholder="例）株式会社エスエイチシー"  name="field2" required></div>                                        
                                    <div class="clearfix"></div>
                                </div>
                                <div class="form-field-cop">
                                    <div class="form-field-lable-cop">メールアドレス<span>必須</span></div> 
                                        <div class="form-field-input-cop"><input type="text" placeholder="例）SHC@sample.com" name="field3" required></div>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="form-field-cop">
                                    <div class="form-field-lable-cop">電話番号<span>必須</span></div> 
                                        <div class="form-field-input-cop"><input type="text" placeholder="例）0120-123-456-789" name="field4" required></div>
                                    <div class="clearfix"></div>
                                </div>                                                                 
                                <div class="form-field-cop">
                                    <div class="form-field-lable-cop">お問合せ内容<span>必須</span></div>                                    
                                        <div class="form-field-input-cop">                                            
                                            <div class="form-list-cop">                                        	
                                                <div class="form-list-select-cop recruitment_width_cp">
                                                    <select class="custom-select" name="field5" required>
                                                        <option value="">選択してください</option>
                                                        <option value="選択1">選択1</option>
                                                        <option value="選択2">選択2</option>
                                                    </select>
                                                </div>                                 
                                            </div>                                                                                        
                                        </div>                                        
                                    <div class="clearfix"></div>
                                </div>                                                                                      
                                <div class="form-field-cop">
                                    <div class="form-field-lable-cop">概要<span>必須</span></div>                                      
                                    <div class="form-field-input-cop"><textarea placeholder="ご自由にご入力ください" name="field6" required></textarea></div>                                                 
                                    <div class="clearfix"></div>
                                </div>
                                <div class="form-field-cop">
                                    <div class="form-field-lable-cop">個人情報の取扱規程<span>必須</span></div> 
                                    <div class="form-field-input-cop"><a href="#"> 「個人情報の取扱いについて</a>」の内容をご確認の上、チェックして下さい</div>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="form-field-cop">
                                    <div class="form-field-lable-cop">&nbsp;</div>                                      
                                    <div class="form-field-checkobx-cop"><input type="checkbox" required>
                                        <label>プライバシーポリシーに同意する</label></div>
                                    <div class="clearfix"></div>
                                </div>
                                <!-- <div class="form-field-radio-main-cp">
                                    <div class="form-field-radio-cp">
                                        <label class="radio-container-cp">プライバシーポリシーに同意する
                                            <input type="checkbox" id="inquiry1" required>
                                            <span class="checkmark-cp" for="inquiry1"></span>
                                        </label>
                                    </div>
                                </div>   -->
                                <div class="form-field-cop">
                                    <div class="form-field-lable-cop"></div>                                      
                                    <div class="form-field-input-cop">
                                        <div class="please_btn_cp">
                                            <input type="hidden" name="submit-confirm" value="submit-confirm">
                                            <button id="submit-btn" type="submit">送信する</button>
                                        </div>
                                    </div>                                                 
                                    <div class="clearfix"></div>
                                </div>                                                                                                                                                                                                  
                            </div>
                            
                        </div>                                               
                        <div class="clearfix"></div>
                    </div>
                </form>
            </div>
        </div>                   
        <div class="clearfix"></div>
    </div>                
</section>

<?php
get_footer();
