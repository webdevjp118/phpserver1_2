<?php
get_header();
?>

<section id="contain">    	        
    <div class="banner_block_hp">             
        <div class="banner_inner_hp" style="position:relative">         
            <div class="fading-wrapper">
                <div class="pic-1" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/images/banner_1.png)"></div>
                <div class="pic-2" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/images/banner_2.png)"></div>
                <div class="pic-3" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/images/banner_3.png)"></div>
                <div class="pic-4" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/images/banner_4.png)"></div>
            </div> 
            <div class="blue-mask"></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 banner_block_in_hp">                         	                   	
                        <div class="banner_middle_hp"> 
                            <div class="banner_title_hp" data-aos="fade-right">		     
                                <h1>採用情報</h1>
                                <h2>Recruit</h2>
                            </div>
                        </div>                                               
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>            
        </div>
        <div class="clearfix"></div>
    </div>
    
    <div class="select_block_rp">           	       
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 select_block_in_rp">
                    <div class="common_title_hp" data-aos="fade-right">
                        <h2>職種から選ぶ</h2>
                    </div>                      	                   	
                    <div class="select_middle_rp">                       		
                        <div class="select_top_rp">
                            <div class="select_box_rp" data-aos="fade-up">
                                <a href="#recruit1">
                                    <div class="select_img_rp">
                                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/select_img1.png" alt=""/>
                                        <div class="select_name_rp">
                                            事務
                                        </div>
                                    </div>      
                                </a>                              
                            </div>
                            <div class="select_box_rp" data-aos="fade-up">
                                <a href="#recruit2">
                                    <div class="select_img_rp">
                                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/select_img2.png" alt=""/>
                                        <div class="select_name_rp">
                                            営業
                                        </div>
                                    </div>   
                                </a>                                 
                            </div>
                            <div class="select_box_rp" data-aos="fade-up">
                                <a href="#recruit3">
                                    <div class="select_img_rp">
                                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/select_img3.png" alt=""/>
                                        <div class="select_name_rp">
                                            現場管理
                                        </div>
                                    </div>      
                                </a>                              
                            </div>
                            <div class="select_box_rp" data-aos="fade-up">
                                <a href="#recruit4">
                                    <div class="select_img_rp">
                                        <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/select_img4.png" alt=""/>
                                        <div class="select_name_rp">
                                            アルバイト
                                        </div>
                                    </div>      
                                </a>                              
                            </div>
                        </div>                                                                                   
                    </div>                                               
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>                   
        <div class="clearfix"></div>
    </div>
    
    <div class="clerical_block_rp" id="recruit1" data-aos="fade-up">           	       
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 clerical_block_in_rp">                    	                      	                   	
                    <div class="clerical_middle_rp">                       		
                        <div class="clerical_img_rp">
                            <a href="#"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/clerical_img1.png" alt=""/></a>
                        </div>                                                                                      
                    </div>                                               
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>                   
        <div class="clearfix"></div>
    </div>
    
    <div class="work_block_rp">           	       
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 work_block_in_rp">                      	                    	                   	
                    <div class="work_middle_rp" data-aos="fade-up">  
                        <div class="common_title_hp">
                            <h2>事務</h2>
                            <p>概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキストがあります。</p>
                        </div>
                        <div class="company_top_cmp work_change_rp">
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    給与
                                </div>
                                <div class="company_info_cmp">
                                    <p>月給200,000円～　※あくまでも最低保障給です。</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    年収例
                                </div>
                                <div class="company_info_cmp">
                                    <p>350万円／事務／未経験1年目／月給25万円</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    勤務時間
                                </div>
                                <div class="company_info_cmp">
                                    <p>9:00~18:00　※担当職種により変動します。</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    待遇
                                </div>
                                <div class="company_info_cmp">
                                    <p>昇給：年1回　賞与：年2回（業績による）/  交通費支給（上限2万円／月まで）</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    休日休暇
                                </div>
                                <div class="company_info_cmp">
                                    <p>週休2日制（土日※土日出社あり）/  年末年始・有給休暇・夏季休暇</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    福利厚生
                                </div>
                                <div class="company_info_cmp">
                                    <p>各種健康保険・資格取得制度</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    勤務地
                                </div>
                                <div class="company_info_cmp">
                                    <p>大阪本社・東京支社</p>
                                </div>
                            </div>
                        </div>  
                    </div>                                               
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>                   
        <div class="clearfix"></div>
    </div>
        
    <div class="clerical_block_rp" id="recruit2" data-aos="fade-up">           	       
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 clerical_block_in_rp">                    	                      	                   	
                    <div class="clerical_middle_rp">                       		
                        <div class="clerical_img_rp">
                            <a href="#"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/sales_img1.png" alt=""/></a>
                        </div>                                                                                      
                    </div>                                               
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>                   
        <div class="clearfix"></div>
    </div> 
    
    <div class="work_block_rp">           	       
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 work_block_in_rp">                      	                    	                   	
                    <div class="work_middle_rp">  
                        <div class="common_title_hp" data-aos="fade-up">
                            <h2>営業</h2>
                            <p>概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキストがあります。</p>
                        </div>
                        <div class="company_top_cmp work_change_rp" data-aos="fade-up">
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    給与
                                </div>
                                <div class="company_info_cmp">
                                    <p>月給200,000円～　※あくまでも最低保障給です。</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    年収例
                                </div>
                                <div class="company_info_cmp">
                                    <p>350万円／事務／未経験1年目／月給25万円</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    勤務時間
                                </div>
                                <div class="company_info_cmp">
                                    <p>9:00~18:00　※担当職種により変動します。</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    待遇
                                </div>
                                <div class="company_info_cmp">
                                    <p>昇給：年1回　賞与：年2回（業績による）/  交通費支給（上限2万円／月まで）</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    休日休暇
                                </div>
                                <div class="company_info_cmp">
                                    <p>週休2日制（土日※土日出社あり）/  年末年始・有給休暇・夏季休暇</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    福利厚生
                                </div>
                                <div class="company_info_cmp">
                                    <p>各種健康保険・資格取得制度</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    勤務地
                                </div>
                                <div class="company_info_cmp">
                                    <p>大阪本社・東京支社</p>
                                </div>
                            </div>
                        </div>  
                    </div>                                               
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>                   
        <div class="clearfix"></div>
    </div>
        
    <div class="clerical_block_rp" id="recruit3" data-aos="fade-up">           	       
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 clerical_block_in_rp">                    	                      	                   	
                    <div class="clerical_middle_rp">                       		
                        <div class="clerical_img_rp">
                            <a href="#"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/site_img1.png" alt=""/></a>
                        </div>                                                                                      
                    </div>                                               
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>                   
        <div class="clearfix"></div>
    </div>   
    <div class="work_block_rp" data-aos="fade-up">           	       
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 work_block_in_rp">                      	                    	                   	
                    <div class="work_middle_rp">  
                        <div class="common_title_hp">
                            <h2>現場管理</h2>
                            <p>概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキストがあります。</p>
                        </div>
                        <div class="company_top_cmp work_change_rp">
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    給与
                                </div>
                                <div class="company_info_cmp">
                                    <p>月給200,000円～　※あくまでも最低保障給です。</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    年収例
                                </div>
                                <div class="company_info_cmp">
                                    <p>350万円／事務／未経験1年目／月給25万円</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    勤務時間
                                </div>
                                <div class="company_info_cmp">
                                    <p>9:00~18:00　※担当職種により変動します。</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    待遇
                                </div>
                                <div class="company_info_cmp">
                                    <p>昇給：年1回　賞与：年2回（業績による）/  交通費支給（上限2万円／月まで）</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    休日休暇
                                </div>
                                <div class="company_info_cmp">
                                    <p>週休2日制（土日※土日出社あり）/  年末年始・有給休暇・夏季休暇</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    福利厚生
                                </div>
                                <div class="company_info_cmp">
                                    <p>各種健康保険・資格取得制度</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    勤務地
                                </div>
                                <div class="company_info_cmp">
                                    <p>大阪本社・東京支社</p>
                                </div>
                            </div>
                        </div>  
                    </div>                                               
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>                   
        <div class="clearfix"></div>
    </div>
    
    <div class="clerical_block_rp" id="recruit4" data-aos="fade-up">           	       
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 clerical_block_in_rp">                    	                      	                   	
                    <div class="clerical_middle_rp">                       		
                        <div class="clerical_img_rp">
                            <a href="#"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/job_img1.png" alt=""/></a>
                        </div>                                                                                      
                    </div>                                               
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>                   
        <div class="clearfix"></div>
    </div>
    <div class="work_block_rp job_pd_rp" data-aos="fade-up">           	       
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 work_block_in_rp">                      	                    	                   	
                    <div class="work_middle_rp">  
                        <div class="common_title_hp">
                            <h2>アルバイト</h2>
                            <p>概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキストがあります。</p>
                        </div>
                        <div class="company_top_cmp work_change_rp">
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    給与
                                </div>
                                <div class="company_info_cmp">
                                    <p>月給200,000円～　※あくまでも最低保障給です。</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    年収例
                                </div>
                                <div class="company_info_cmp">
                                    <p>350万円／事務／未経験1年目／月給25万円</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    勤務時間
                                </div>
                                <div class="company_info_cmp">
                                    <p>9:00~18:00　※担当職種により変動します。</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    待遇
                                </div>
                                <div class="company_info_cmp">
                                    <p>昇給：年1回　賞与：年2回（業績による）/  交通費支給（上限2万円／月まで）</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    休日休暇
                                </div>
                                <div class="company_info_cmp">
                                    <p>週休2日制（土日※土日出社あり）/  年末年始・有給休暇・夏季休暇</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    福利厚生
                                </div>
                                <div class="company_info_cmp">
                                    <p>各種健康保険・資格取得制度</p>
                                </div>
                            </div>
                            <div class="company_box_cmp">
                                <div class="company_title_cmp">
                                    勤務地
                                </div>
                                <div class="company_info_cmp">
                                    <p>大阪本社・東京支社</p>
                                </div>
                            </div>
                        </div>  
                    </div>                                               
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>                   
        <div class="clearfix"></div>
    </div>             
</section>

<?php
get_footer();
