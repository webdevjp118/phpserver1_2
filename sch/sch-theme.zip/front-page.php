<?php
get_header();
?>

<section id="contain">    	        
    <div class="banner_block_tp first">   
        <div class="banner_inner_tp" style="position:relative">         
            <div class="fading-wrapper">
                <div class="pic-1" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/images/banner_1.png)"></div>
                <div class="pic-2" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/images/banner_2.png)"></div>
                <div class="pic-3" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/images/banner_3.png)"></div>
                <div class="pic-4" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/images/banner_4.png)"></div>
            </div> 
            <div class="blue-mask"></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 banner_block_in_tp">                     	
                        <div class="banner_middle_tp">
                            <div class="banner_info_tp">
                                <h4 data-aos="fade-right" data-aos-delay="300">すべての方に</h4>
                                <p data-aos="fade-right" data-aos-delay="400">with success and honest to all</p>
                                <h4 data-aos="fade-right" data-aos-delay="500">成功と誠実な気持ちで</h4>
                                <p data-aos="fade-right" data-aos-delay="600">I will consult</p>
                                <h4 data-aos="fade-right" data-aos-delay="700">お応え致します</h4>
                            </div>
                        </div>                                               
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>            
        <div class="clearfix"></div>
    </div>
    
    <div class="january_block_tp">           	       
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 january_block_in_tp">                     	
                    <div class="january_middle_tp">
                        <div class="january_top_tp">
                            <div class="january_left_tp">
                                <div class="january_in_left_tp">
                                    <div class="january_info_tp" data-aos="fade-right">
                                        <p>
                                            2023年1月11日でエスエイチシーは創立10周年を迎えました。 <br />
                                            私たちは、「成功」を目指す皆さまの後押しをする企業でありたい。</p>
                                        <p>
                                            いつでもあなたの側にいる、そんなかけがえのない存在を目指して<br />
                                            私たちは「誠実な気持ち」で取り組んでまいります。 <br />
                                            次の10年もこうして皆さまにご挨拶させていただくことを 心より楽しみにしております。
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="january_right_tp" data-aos="zoom-in">
                                <a href="#"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/january_img1.png" alt=""/></a>
                            </div>
                        </div>
                    </div>                                               
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>                   
        <div class="clearfix"></div>
    </div>                
</section>

<?php
get_footer();
?>