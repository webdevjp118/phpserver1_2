<?php
get_header();
?>

<section id="contain">    	        
	<div class="banner_block_hp">
		<div class="banner_inner_hp" style="position:relative">         
            <div class="fading-wrapper">
                <div class="pic-1" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/images/banner_1.png)"></div>
                <div class="pic-2" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/images/banner_2.png)"></div>
                <div class="pic-3" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/images/banner_3.png)"></div>
                <div class="pic-4" style="background-image:url(<?php echo get_stylesheet_directory_uri(); ?>/images/banner_4.png)"></div>
            </div> 
            <div class="blue-mask"></div>
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 banner_block_in_hp">                         	                   	
						<div class="banner_middle_hp"> 
							<div class="banner_title_hp" data-aos="fade-right">		     
								<h1>企業情報</h1>
								<h2>Company</h2>
							</div>
						</div>                                               
						<div class="clearfix"></div>
					</div>
				</div>
			</div>            
		</div>
		<div class="clearfix"></div>
	</div>
	
	<div class="for_block_cmp">           	       
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 for_block_in_cmp">
					<div class="common_title_hp common_change_cp for_change_cmp">
						<h2>vision</h2>
					</div>                      	                   	
					<div class="for_middle_cmp">                       		
						<div class="for_title_cmp" data-aos="fade-up">
							<h3>すべての方に</h3>
							<p>with success and honest to all</p>
							<h3>成功と誠実な気持ちで</h3>
							<p>I will consult </p>
							<h3>お応え致します</h3>
						</div>
						<div class="for_info_cmp" data-aos="fade-up">
							<p>
								概要テキスト概要テキスト概要テキスト概要テキスト<br />
								概要テキスト概要テキストがあります。<br />
								概要テキスト概要テキスト概要テキスト概要テキスト<br />
								概要テキスト概要テキストがあります。
							</p>
							<p>
								概要テキスト概要テキスト概要テキスト概要テキスト<br />
								概要テキスト概要テキストがあります。<br />
								概要テキスト概要テキスト概要テキスト概要テキスト<br />
								概要テキスト概要テキストがあります。
							</p>
						</div>                                                       
					</div>                                               
					<div class="clearfix"></div>
				</div>
			</div>
		</div>                   
		<div class="clearfix"></div>
	</div>
	
	<div class="message_block_cmp">           	       
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 message_block_in_cmp">  
					<div class="common_title_hp common_change_cp message_change_cmp">
						<h2>Message</h2>
					</div>                    	                   	
					<div class="message_middle_cmp">  
						<div class="message_top_cmp">
							<div class="message_box_cmp">
								<div class="message_left_cmp" data-aos="fade-right">
									<a href="#"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/for_img1.png" alt=""/></a>
								</div>
								<div class="message_right_cmp" data-aos="fade-left">
									<div class="message_info_cmp">
										概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキストがあります。<br />
										概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキストがあります。<br />
										概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキスト概要テキストがあります。
									</div>
									<div class="message_row_cmp">
										<div class="message_title_cmp">
											代表取締役
										</div>
										<div class="message_sign_cmp">
											名前テキスト
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>                                               
					<div class="clearfix"></div>
				</div>
			</div>
		</div>                   
		<div class="clearfix"></div>
	</div>
	
	<div class="company_block_cmp">           	       
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 company_block_in_cmp">  
					<div class="common_title_hp common_change_cp company_change_cmp">
						<h2>company</h2>
					</div>                    	                   	
					<div class="company_middle_cmp" data-aos="fade-up">  
						<div class="company_top_cmp">
							<div class="company_box_cmp">
								<div class="company_title_cmp">
									会社名
								</div>
								<div class="company_info_cmp">
									<p>株式会社エスエイチシー</p>
								</div>
							</div>
							<div class="company_box_cmp">
								<div class="company_title_cmp">
									設立日
								</div>
								<div class="company_info_cmp">
									<p>2013年1月11日</p>
								</div>
							</div>
							<div class="company_box_cmp">
								<div class="company_title_cmp">
									資本金
								</div>
								<div class="company_info_cmp">
									<p>600万円</p>
								</div>
							</div>
							<div class="company_box_cmp">
								<div class="company_title_cmp">
									決算期
								</div>
								<div class="company_info_cmp">
									<p>12月</p>
								</div>
							</div>
							<div class="company_box_cmp">
								<div class="company_title_cmp">
									従業員数
								</div>
								<div class="company_info_cmp">
									<p>20名</p>
								</div>
							</div>
							<div class="company_box_cmp">
								<div class="company_title_cmp">
									メールアドレス
								</div>
								<div class="company_info_cmp">
									<p>info@shc2013.com</p>
								</div>
							</div>
							<div class="company_box_cmp">
								<div class="company_title_cmp">
									ホームページ
								</div>
								<div class="company_info_cmp">
									<p>http://shc2013.com/</p>
								</div>
							</div>
							<div class="company_box_cmp">
								<div class="company_title_cmp">
									営業時間
								</div>
								<div class="company_info_cmp">
									<p>10:00-19:00</p>
								</div>
							</div>
							<div class="company_box_cmp">
								<div class="company_title_cmp">
									業務内容
								</div>
								<div class="company_info_cmp">
									<p>
										■短期人材サービス事業<br />
										・イベント施工サービス<br />
										・イベント運営サービス<br />
										・内装施工サービス<br />
										・軽作業・各種請負サービス
									</p>
									<p>■有料職業紹介事業</p>
								</div>
							</div>
							<div class="company_box_cmp">
								<div class="company_title_cmp">
									許認可
								</div>
								<div class="company_info_cmp">
									<p>有料職業紹介事業(許可証：〇〇〇〇〇)</p>                                    		
								</div>
							</div>
							<div class="company_box_cmp">
								<div class="company_title_cmp">
									加入保険
								</div>
								<div class="company_info_cmp">
									<p>〇〇〇(対人・対物)／〇〇〇(業務災害)</p>
								</div>
							</div>
							<div class="company_box_cmp">
								<div class="company_title_cmp">
									取引先企業
								</div>
								<div class="company_info_cmp">
									<p>451社(2021年4月時点)</p>
								</div>
							</div>
						</div>  
					</div>                                               
					<div class="clearfix"></div>
				</div>
			</div>
		</div>                   
		<div class="clearfix"></div>
	</div>
		
		
	<div class="branch_block_cmp">           	       
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 branch_block_in_cmp">  
					<div class="common_title_hp">
						<h2>支店一覧</h2>
					</div>                    	                   	
					<div class="branch_middle_cmp">  
						<div class="branch_top_cmp">
							<div class="branch_box_cmp">
								<div class="branch_name_cmp">
									株式会社エスエイチシー　大阪本社
								</div>
								<div class="branch_row_cmp">
									<div class="branch_left_cmp" data-aos="fade-right">
										<div class="branch_title_cmp">
											〒556-0016<br />
											大阪府大阪市浪速区元町1-5-7 ナンバプラザビル6F
										</div>
										<div class="branch_grid_cmp">
											<div class="branch_grid_row_cmp">
												<div class="branch_subtitle_cmp">
													代表番号
												</div>
												<div class="branch_info_cmp">
													03-5468-6171
												</div>
											</div>
											<div class="branch_grid_row_cmp">
												<div class="branch_subtitle_cmp">
													FAX番号
												</div>
												<div class="branch_info_cmp">
													03-5468-6172
												</div>
											</div>
											<div class="branch_grid_row_cmp">
												<div class="branch_subtitle_cmp">
													お問い合せ
												</div>
												<div class="branch_info_cmp">
													info1@sch2013.com
												</div>
											</div>
											<div class="branch_grid_row_cmp">
												<div class="branch_subtitle_cmp">
													営業時間
												</div>
												<div class="branch_info_cmp">
													10:00-19：00
												</div>
											</div>
											<div class="branch_grid_row_cmp">
												<div class="branch_subtitle_cmp">
													登録面接会日
												</div>
												<div class="branch_info_cmp">
													電話受付(要予約)
												</div>
											</div>
											<div class="branch_grid_row_cmp">
												<div class="branch_subtitle_cmp">
													スタッフ問い合せ番号
												</div>
												<div class="branch_info_cmp">
													03-5468-6174
												</div>
											</div>
										</div>
									</div>
									<div class="branch_right_cmp" data-aos="fade-left">
										<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3281.612083409575!2d135.49545281553162!3d34.66449839266326!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6000e76d4d90b7cf%3A0x232917f4fb0ba2c4!2sNanba%20Plaza%20Building!5e0!3m2!1sen!2sin!4v1678120804184!5m2!1sen!2sin" width="100%" height="350" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
									</div>
								</div>
							</div>
							<div class="branch_box_cmp">
								<div class="branch_name_cmp">
									株式会社エスエイチシー　東京支店
								</div>
								<div class="branch_row_cmp">
									<div class="branch_left_cmp" data-aos="fade-right">
										<div class="branch_title_cmp">
											〒150-0002<br />
											東京都渋谷区渋谷2-14-6 第二かわなビル6F
										</div>
										<div class="branch_grid_cmp">
											<div class="branch_grid_row_cmp">
												<div class="branch_subtitle_cmp">
													代表番号
												</div>
												<div class="branch_info_cmp">
													03-5468-6171
												</div>
											</div>
											<div class="branch_grid_row_cmp">
												<div class="branch_subtitle_cmp">
													FAX番号
												</div>
												<div class="branch_info_cmp">
													03-5468-6172
												</div>
											</div>
											<div class="branch_grid_row_cmp">
												<div class="branch_subtitle_cmp">
													お問い合せ
												</div>
												<div class="branch_info_cmp">
													info1@sch2013.com
												</div>
											</div>
											<div class="branch_grid_row_cmp">
												<div class="branch_subtitle_cmp">
													営業時間
												</div>
												<div class="branch_info_cmp">
													10:00-19：00
												</div>
											</div>
											<div class="branch_grid_row_cmp">
												<div class="branch_subtitle_cmp">
													登録面接会日
												</div>
												<div class="branch_info_cmp">
													電話受付(要予約)
												</div>
											</div>
											<div class="branch_grid_row_cmp">
												<div class="branch_subtitle_cmp">
													スタッフ問い合せ番号
												</div>
												<div class="branch_info_cmp">
													03-5468-6174
												</div>
											</div>
										</div>
									</div>
									<div class="branch_right_cmp" data-aos="fade-left">
										<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3281.612083409575!2d135.49545281553162!3d34.66449839266326!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6000e76d4d90b7cf%3A0x232917f4fb0ba2c4!2sNanba%20Plaza%20Building!5e0!3m2!1sen!2sin!4v1678120804184!5m2!1sen!2sin" width="100%" height="350" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
									</div>
								</div>
							</div>
						</div>
					</div>                                               
					<div class="clearfix"></div>
				</div>
			</div>
		</div>                   
		<div class="clearfix"></div>
	</div>  
					
</section>

<?php
get_footer();
